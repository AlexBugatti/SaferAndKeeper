//
//  Extension+NSObject.swift
//  EnigmaDefense
//
//  Created by Александр on 19.04.2021.
//

import Foundation

extension NSObject {
    
    static var stringIdentifier: String {
        return String(describing: self)
    }
    
}
